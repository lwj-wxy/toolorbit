globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/YDcZ9bWEyJw1fM-N9rUXp/_buildManifest.js",
    "static/YDcZ9bWEyJw1fM-N9rUXp/_ssgManifest.js",
    "static/YDcZ9bWEyJw1fM-N9rUXp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/06lc3hs7dr52k.js",
    "static/chunks/04.i-__.as.dk.js",
    "static/chunks/14cxh-ds9nz1e.js",
    "static/chunks/0hfw~zchjv985.js",
    "static/chunks/turbopack-0g9tahej.aw1i.js"
  ]
};
