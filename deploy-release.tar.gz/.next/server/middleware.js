var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__13yskit._.js")
R.c("server/chunks/[root-of-the-server]__0w12uzf._.js")
R.m(489997)
module.exports=R.m(489997).exports
