1:"$Sreact.fragment"
6:I[667351,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0w~h7b4ikm.kt.js"],"default"]
8:I[897367,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"OutletBoundary"]
9:"$Sreact.suspense"
2:T1244,[{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"ToolOrbit","item":"https://toolorbit.site"},{"@type":"ListItem","position":2,"name":"Blog","item":"https://toolorbit.site/blog"},{"@type":"ListItem","position":3,"name":"How Much Does Etsy Take Per Sale?","item":"https://toolorbit.site/blog/how-much-does-etsy-take-per-sale"}]},{"@context":"https://schema.org","@type":"BlogPosting","headline":"How Much Does Etsy Take Per Sale?","description":"Etsy takes about 10% of a typical US sale — a $0.20 listing fee, 6.5% transaction fee, and 3% + $0.25 payment processing. See what you keep per order.","articleSection":"Business","wordCount":555,"url":"https://toolorbit.site/blog/how-much-does-etsy-take-per-sale","mainEntityOfPage":"https://toolorbit.site/blog/how-much-does-etsy-take-per-sale","datePublished":"2026-08-10","dateModified":"2026-08-10","author":{"@type":"Organization","@id":"https://toolorbit.site/authors/toolorbit-editorial-team#author","name":"ToolOrbit Editorial Team","url":"https://toolorbit.site/authors/toolorbit-editorial-team","description":"The ToolOrbit Editorial Team maintains AI tool guides, browser utility notes, ecommerce fee explanations, and PDF and image workflows. Editors test steps with sample inputs, document limits, and keep feedback routed through the public ToolOrbit contact.","knowsAbout":"Browser tools, ecommerce calculations, and workflow reviews","parentOrganization":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"}},"publisher":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"},"reviewedBy":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"},"inLanguage":"en","publishingPrinciples":"https://toolorbit.site/about","about":[{"@type":"WebApplication","name":"Etsy Fee Calculator - Profit, Shipping & Offsite Ads","url":"https://toolorbit.site/tools/ecommerce/etsy-fee-calculator"},{"@type":"WebApplication","name":"Etsy Pricing Calculator - Reverse Target Profit Price","url":"https://toolorbit.site/tools/ecommerce/etsy-pricing-calculator"},{"@type":"WebApplication","name":"Etsy Offsite Ads Calculator - 12%, 15% & $100 Cap","url":"https://toolorbit.site/tools/ecommerce/etsy-offsite-ads-calculator"}]}]0:{"rsc":["$","$1","c",{"children":[[["$","script",null,{"id":"structured-data-blog-how-much-does-etsy-take-per-sale","type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"$2"}}],"$L3"],["$L4"],"$L5"]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"YDcZ9bWEyJw1fM-N9rUXp"}
7:Te6f,# How Much Does Etsy Take Per Sale? A Simple Way to Estimate Your Payout

There is no single Etsy percentage that applies to every seller and every order. The amount deducted depends on the seller country, order total, payment processing, listing or renewal charges, currency conversion, and possible Offsite Ads attribution.

For the current rules, check Etsy's [official fees policy](https://www.etsy.com/legal/fees/). For a specific order, use the [Etsy Fee Calculator](/tools/ecommerce/etsy-fee-calculator).

## Start with a complete order total

Suppose a buyer pays for an item, shipping, and personalization. Do not estimate the payout from the item price alone. Write down every part of the order total, then identify which charges each fee uses as its base.

The exact fee base and rate can change by policy and seller location. Your Etsy payment statement is the final record for the order.

## The basic calculation

For a US example, a seller may model a listing fee, a transaction percentage, and an Etsy Payments percentage plus fixed processing fee. Sellers in other countries need to enter the payment processing rate for their own account.

```text
Estimated payout = order total
- listing or renewal fee
- transaction fee
- payment processing fee
- country-specific fees
- currency conversion, if applicable
- Offsite Ads fee, if attributed
```

This is an estimate, not a universal Etsy formula. Use it to plan prices and compare it with the statement after the sale.

## Why low-priced products feel more expensive

Fixed fees take a larger share of a small order. A $10 order and a $100 order may have similar percentage fees, but the fixed listing and payment components make the effective rate higher on the $10 order.

That is why low-priced products should be modeled with their actual average order value. Bundles can improve the effective rate when they increase order value without increasing labor and shipping at the same pace.

## Include the fees that are conditional

Offsite Ads can add a fee to an attributed order. Currency conversion can reduce a payout when listing and bank currencies do not match. Country-specific operating or regulatory fees may apply to some seller accounts.

Run an organic and an attributed scenario for products with narrow margins. If the product is only profitable without the conditional fee, consider changing the price, bundle, or product mix.

## Example using an order model

Assume a seller receives a $60 item price and $8 shipping charge. The model should include the $68 order amount where applicable, then subtract the seller-country transaction and processing fees, listing cost, shipping label, packaging, materials, and labor.

The important output is not the platform deduction alone. It is the contribution profit left after the costs required to fulfill the order.

## How to verify the estimate

1. Enter the order values and seller country in the calculator.
2. Save the result with the order number.
3. Compare the estimate with the Etsy payment statement.
4. Investigate differences caused by refunds, taxes, ads, conversion, or shipping labels.
5. Update the price model when the difference repeats across several orders.

## What to remember

- Etsy does not take one universal percentage from every sale.
- Shipping and extras can affect the fee base.
- Seller-country payment processing rates matter.
- Fixed fees make small orders more expensive as a percentage.
- Offsite Ads and currency conversion need separate scenarios.
- The final payout statement is more reliable than a remembered rate.

Use the calculator for planning, the official policy for current rules, and your statement for bookkeeping.
3:["$","$L6",null,{"slug":"how-much-does-etsy-take-per-sale","initialMarkdown":"$7"}]
4:["$","script","script-0",{"src":"/_next/static/chunks/0w~h7b4ikm.kt.js","async":true}]
5:["$","$L8",null,{"children":["$","$9",null,{"name":"Next.MetadataOutlet","children":"$@a"}]}]
a:null
