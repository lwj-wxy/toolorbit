1:"$Sreact.fragment"
2:I[464006,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
a:I[168027,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default",1]
:HL["/_next/static/chunks/0em5p-gnhafm7.css","style"]
3:T560,{"@context":"https://schema.org","@type":"WebSite","@id":"https://toolorbit.site/#website","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","publisher":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"},"potentialAction":{"@type":"SearchAction","target":"https://toolorbit.site/?search={search_term_string}","query-input":"required name=search_term_string"}}0:{"P":null,"c":["","blog","etsy-fee-complete-guide"],"q":"","i":false,"f":[[["",{"children":["blog",{"children":[["slug","etsy-fee-complete-guide","d",null],{"children":["__PAGE__",{}]},"$undefined","$undefined",4]},"$undefined","$undefined",8]},"$undefined","$undefined",24],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0em5p-gnhafm7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0ywkc-4sl20yh.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/187jubqbbak9g.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/0r5yttdyrak~f.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/0pct.mc7q8w0q.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/0i.l9589uvx0j.js","async":true,"nonce":"$undefined"}]],["$","$L2",null,{"children":[["$","head",null,{"children":["$","script",null,{"async":true,"src":"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5608961818345363","crossOrigin":"anonymous","data-toolorbit-adsense":"ca-pub-5608961818345363"}]}],["$","body",null,{"suppressHydrationWarning":true,"children":[["$","script",null,{"id":"structured-data-organization","type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"@id\":\"https://toolorbit.site/#organization\",\"name\":\"ToolOrbit\",\"alternateName\":[\"ToolOrbit.site\",\"Tool Orbit\"],\"url\":\"https://toolorbit.site\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://toolorbit.site/icon.svg\"},\"email\":\"luowj1998@outlook.com\",\"description\":\"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.\",\"knowsAbout\":[\"browser-based developer tools\",\"client-side data processing\",\"PDF workflow utilities\",\"image optimization\",\"AI-assisted content and ecommerce workflows\",\"ecommerce operations tools\",\"technical writing for practical workflows\"],\"contactPoint\":{\"@type\":\"ContactPoint\",\"email\":\"luowj1998@outlook.com\",\"contactType\":\"customer support\",\"availableLanguage\":[\"English\",\"Chinese\"]},\"publishingPrinciples\":\"https://toolorbit.site/about\"}"}}],["$","script",null,{"id":"structured-data-website","type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"$3"}}],"$L4"]}]]}]]}],{"children":["$L5",{"children":["$L6",{"children":["$L7",{},null,false,null]},null,false,"$@8"]},null,false,"$@8"]},null,false,null],"$L9",false]],"m":"$undefined","G":["$a",["$Lb"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"YDcZ9bWEyJw1fM-N9rUXp"}
c:I[544636,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
d:I[705113,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
e:I[858190,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
f:I[339756,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
10:I[758298,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0cdvgm96-27wh.js"],"default"]
11:I[837457,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
12:I[12158,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/13hpq9_nbe25b.js"],"default"]
13:I[522016,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/13hpq9_nbe25b.js"],""]
14:I[814806,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
15:I[339756,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"LoadingBoundaryProvider"]
16:I[171578,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/035cotrure2y_.js"],"default"]
18:I[897367,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"OutletBoundary"]
19:"$Sreact.suspense"
1c:I[897367,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"ViewportBoundary"]
1e:I[897367,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"MetadataBoundary"]
4:["$","$Lc",null,{"adsenseClient":"ca-pub-5608961818345363","gaMeasurementId":"G-B7N9BGZ2B0","toolTrackingData":[{"id":"etsy-fee-calculator","path":"/tools/ecommerce/etsy-fee-calculator"},{"id":"etsy-offsite-ads-calculator","path":"/tools/ecommerce/etsy-offsite-ads-calculator"},{"id":"etsy-pricing-calculator","path":"/tools/ecommerce/etsy-pricing-calculator"},{"id":"etsy-regulatory-fee-calculator","path":"/tools/ecommerce/etsy-regulatory-fee-calculator"},{"id":"etsy-tag-generator","path":"/tools/ecommerce/etsy-tag-generator"},{"id":"etsy-free-shipping-calculator","path":"/tools/ecommerce/etsy-free-shipping-calculator"},{"id":"stripe-fee-calculator","path":"/tools/ecommerce/stripe-fee-calculator"},{"id":"paypal-fee-calculator","path":"/tools/ecommerce/paypal-fee-calculator"},{"id":"stripe-vs-paypal-fee-calculator","path":"/tools/ecommerce/stripe-vs-paypal-fee-calculator"},{"id":"listing-generator","path":"/tools/ai/listing-generator"},{"id":"keyword-analyzer","path":"/tools/ai/keyword-analyzer"},{"id":"ai-hs-code-assistant","path":"/tools/ai/hs-code-assistant"},{"id":"ai-product-asset-checker","path":"/tools/ai/product-asset-checker"},{"id":"ai-product-image-generator","path":"/tools/ai/product-image-generator"}],"children":["$","div",null,{"className":"relative flex min-h-screen flex-col overflow-x-clip bg-[var(--app-bg)] font-sans text-[var(--app-text)] transition-colors duration-300 dark:bg-[var(--app-bg)] dark:text-[var(--app-text)]","children":[["$","a",null,{"href":"#main-content","className":"sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[999] focus:rounded-md focus:bg-[var(--app-accent-strong)] focus:px-4 focus:py-2 focus:font-semibold focus:text-white focus:outline-none","children":"Skip to main content"}],["$","div",null,{"className":"pointer-events-none absolute inset-0 z-0 overflow-hidden bg-[var(--app-bg)] dark:bg-[var(--app-bg)]","children":["$","div",null,{"className":"absolute inset-x-0 top-0 h-px bg-[color-mix(in_srgb,var(--app-accent)_34%,transparent)]"}]}],["$","$Ld",null,{}],["$","div",null,{"className":"relative z-10 mx-auto flex w-full max-w-[1440px] min-w-0 flex-1 flex-col px-4 pb-7 pt-[calc(68px+1.75rem)] sm:px-6 md:pb-9 md:pt-[calc(68px+2.5rem)] lg:px-10","children":[["$","main",null,{"id":"main-content","className":"w-full min-w-0","children":[["$","$Le",null,{"slot":"before-content"}],["$","div",null,{"children":["$","$Lf",null,{"parallelRouterKey":"children","error":"$10","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/0cdvgm96-27wh.js","async":true}]],"template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"mx-auto flex min-h-[60vh] max-w-2xl flex-col items-center justify-center px-6 py-16 text-center","children":[["$","$L12",null,{}],["$","p",null,{"className":"text-sm font-bold uppercase tracking-wider text-blue-600","children":"404"}],["$","h1",null,{"className":"mt-3 text-4xl font-black tracking-tight text-slate-950 dark:text-white","children":"Page not found"}],["$","p",null,{"className":"mt-4 text-base leading-7 text-slate-600 dark:text-slate-300","children":"This ToolOrbit page does not exist or has been moved. Use the tool directory to find the current utility."}],["$","$L13",null,{"href":"/","className":"mt-8 rounded-lg bg-blue-600 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-blue-700","children":"Back to tools"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}],["$","$Le",null,{"slot":"after-content"}]]}],["$","$L14",null,{}]]}]}]
5:["$","$1","c",{"children":[null,["$","$Lf",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
6:["$","$L15",null,{"loading":[["$","div","l",{"className":"mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8","children":[["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 mb-8 h-4 w-56"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 mb-4 h-5 w-40"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 mb-5 h-12 w-full max-w-3xl"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 mb-8 h-12 w-3/4"}],["$","div",null,{"className":"animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-800 mb-12 h-[360px] w-full md:h-[460px]"}],["$","div",null,{"className":"space-y-4","children":[["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 h-5 w-full"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 h-5 w-11/12"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 h-5 w-10/12"}],["$","div",null,{"className":"animate-pulse rounded-full bg-slate-200 dark:bg-slate-800 h-5 w-full"}]]}]]}],[],[]],"children":["$","$1","c",{"children":[null,["$","$Lf",null,{"parallelRouterKey":"children","error":"$16","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/035cotrure2y_.js","async":true}]],"template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]}]
7:["$","$1","c",{"children":["$L17",[["$","script","script-0",{"src":"/_next/static/chunks/0w~h7b4ikm.kt.js","async":true,"nonce":"$undefined"}]],["$","$L18",null,{"children":["$","$19",null,{"name":"Next.MetadataOutlet","children":"$@1a"}]}]]}]
1b:[]
8:"$W1b"
9:["$","$1","h",{"children":[null,["$","$L1c",null,{"children":"$L1d"}],["$","div",null,{"hidden":true,"children":["$","$L1e",null,{"children":["$","$19",null,{"name":"Next.Metadata","children":"$L1f"}]}]}],null]}]
b:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0em5p-gnhafm7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
1d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1a:null
1f:[["$","title","0",{"children":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays | ToolOrbit"}],["$","meta","1",{"name":"description","content":"Etsy charges listing fees, transaction fees, payment processing, Offsite Ads, regulatory fees, and currency conversion. Here's the full breakdown."}],["$","meta","2",{"name":"application-name","content":"ToolOrbit"}],["$","link","3",{"rel":"author","href":"https://toolorbit.site/authors/toolorbit-editorial-team"}],["$","meta","4",{"name":"author","content":"ToolOrbit Editorial Team"}],["$","link","5",{"rel":"manifest","href":"/manifest.json","crossOrigin":"$undefined"}],["$","meta","6",{"name":"creator","content":"ToolOrbit"}],["$","meta","7",{"name":"publisher","content":"ToolOrbit"}],["$","meta","8",{"name":"robots","content":"index, follow"}],["$","meta","9",{"name":"googlebot","content":"index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1"}],["$","meta","10",{"name":"google-adsense-account","content":"ca-pub-5608961818345363"}],["$","link","11",{"rel":"canonical","href":"https://toolorbit.site/blog/etsy-fee-complete-guide"}],["$","link","12",{"rel":"alternate","hrefLang":"en","href":"https://toolorbit.site/blog/etsy-fee-complete-guide"}],["$","link","13",{"rel":"alternate","hrefLang":"en-US","href":"https://toolorbit.site/blog/etsy-fee-complete-guide"}],["$","link","14",{"rel":"alternate","hrefLang":"x-default","href":"https://toolorbit.site/blog/etsy-fee-complete-guide"}],["$","meta","15",{"property":"og:title","content":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays | ToolOrbit"}],["$","meta","16",{"property":"og:description","content":"Etsy charges listing fees, transaction fees, payment processing, Offsite Ads, regulatory fees, and currency conversion. Here's the full breakdown."}],["$","meta","17",{"property":"og:url","content":"https://toolorbit.site/blog/etsy-fee-complete-guide"}],["$","meta","18",{"property":"og:site_name","content":"ToolOrbit"}],["$","meta","19",{"property":"og:locale","content":"en_US"}],["$","meta","20",{"property":"og:image","content":"https://toolorbit.site/og-image?title=The+Complete+Guide+to+Etsy+Fees+in+2026%3A+What+Every+Seller+Actually+Pays&description=Etsy+charges+listing+fees%2C+transaction+fees%2C+payment+processing%2C+Offsite+Ads%2C+regulatory+fees%2C+and+currency+conversion.+Here%27s+the+full+breakdown."}],["$","meta","21",{"property":"og:image:width","content":"1200"}],["$","meta","22",{"property":"og:image:height","content":"630"}],["$","meta","23",{"property":"og:image:alt","content":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays"}],["$","meta","24",{"property":"og:type","content":"article"}],["$","meta","25",{"property":"article:published_time","content":"2026-08-11"}],["$","meta","26",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","27",{"name":"twitter:title","content":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays | ToolOrbit"}],["$","meta","28",{"name":"twitter:description","content":"Etsy charges listing fees, transaction fees, payment processing, Offsite Ads, regulatory fees, and currency conversion. Here's the full breakdown."}],["$","meta","29",{"name":"twitter:image","content":"https://toolorbit.site/og-image?title=The+Complete+Guide+to+Etsy+Fees+in+2026%3A+What+Every+Seller+Actually+Pays&description=Etsy+charges+listing+fees%2C+transaction+fees%2C+payment+processing%2C+Offsite+Ads%2C+regulatory+fees%2C+and+currency+conversion.+Here%27s+the+full+breakdown."}],["$","meta","30",{"name":"twitter:image:alt","content":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays"}],["$","meta","31",{"name":"twitter:image:width","content":"1200"}],["$","meta","32",{"name":"twitter:image:height","content":"630"}],["$","link","33",{"rel":"icon","href":"/favicon.ico","sizes":"any"}],["$","link","34",{"rel":"icon","href":"/favicon-16x16.png","sizes":"16x16","type":"image/png"}],"$L20","$L21","$L22","$L23"]
24:I[27201,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"IconMark"]
20:["$","link","35",{"rel":"icon","href":"/favicon-32x32.png","sizes":"32x32","type":"image/png"}]
21:["$","link","36",{"rel":"icon","href":"/icon.svg","type":"image/svg+xml"}]
22:["$","link","37",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png","sizes":"180x180","type":"image/png"}]
23:["$","$L24","38",{}]
25:T127c,[{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"ToolOrbit","item":"https://toolorbit.site"},{"@type":"ListItem","position":2,"name":"Blog","item":"https://toolorbit.site/blog"},{"@type":"ListItem","position":3,"name":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays","item":"https://toolorbit.site/blog/etsy-fee-complete-guide"}]},{"@context":"https://schema.org","@type":"BlogPosting","headline":"The Complete Guide to Etsy Fees in 2026: What Every Seller Actually Pays","description":"Etsy charges listing fees, transaction fees, payment processing, Offsite Ads, regulatory fees, and currency conversion. Here's the full breakdown.","articleSection":"Business","wordCount":898,"url":"https://toolorbit.site/blog/etsy-fee-complete-guide","mainEntityOfPage":"https://toolorbit.site/blog/etsy-fee-complete-guide","datePublished":"2026-08-11","dateModified":"2026-08-11","author":{"@type":"Organization","@id":"https://toolorbit.site/authors/toolorbit-editorial-team#author","name":"ToolOrbit Editorial Team","url":"https://toolorbit.site/authors/toolorbit-editorial-team","description":"The ToolOrbit Editorial Team maintains AI tool guides, browser utility notes, ecommerce fee explanations, and PDF and image workflows. Editors test steps with sample inputs, document limits, and keep feedback routed through the public ToolOrbit contact.","knowsAbout":"Browser tools, ecommerce calculations, and workflow reviews","parentOrganization":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"}},"publisher":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"},"reviewedBy":{"@type":"Organization","@id":"https://toolorbit.site/#organization","name":"ToolOrbit","alternateName":["ToolOrbit.site","Tool Orbit"],"url":"https://toolorbit.site","logo":{"@type":"ImageObject","url":"https://toolorbit.site/icon.svg"},"email":"luowj1998@outlook.com","description":"Listing draft, file handling, developer check, and fee review tools for tasks that need clear inputs, visible results, and human review.","knowsAbout":["browser-based developer tools","client-side data processing","PDF workflow utilities","image optimization","AI-assisted content and ecommerce workflows","ecommerce operations tools","technical writing for practical workflows"],"contactPoint":{"@type":"ContactPoint","email":"luowj1998@outlook.com","contactType":"customer support","availableLanguage":["English","Chinese"]},"publishingPrinciples":"https://toolorbit.site/about"},"inLanguage":"en","publishingPrinciples":"https://toolorbit.site/about","about":[{"@type":"WebApplication","name":"Etsy Fee Calculator - Profit, Shipping & Offsite Ads","url":"https://toolorbit.site/tools/ecommerce/etsy-fee-calculator"},{"@type":"WebApplication","name":"Etsy Pricing Calculator - Reverse Target Profit Price","url":"https://toolorbit.site/tools/ecommerce/etsy-pricing-calculator"},{"@type":"WebApplication","name":"Stripe Fee Online Calculator - Global Credit Card Processing Costs","url":"https://toolorbit.site/tools/ecommerce/stripe-fee-calculator"}]}]17:[["$","script",null,{"id":"structured-data-blog-etsy-fee-complete-guide","type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"$25"}}],"$L26"]
27:I[667351,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/0w~h7b4ikm.kt.js"],"default"]
28:T1619,# Etsy Fees 2026: Complete Order-Level Breakdown & Margin Guide

An Etsy sale is not net income. Every transaction incurs multiple fee layers depending on your item price, buyer-paid shipping, payment processing region, listing currency, and advertising status.

To model your exact profit on specific price points, use the [Etsy Fee Calculator](/tools/ecommerce/etsy-fee-calculator). This guide breaks down Etsy's 2026 fee structure step by step, with order-level formulas and margin optimization rules.

---

## 1. The Order Total Base

Before calculating percentage fees, understand what Etsy considers the **chargeable order total**.

Percentage-based fees (such as transaction fees, payment processing, and Offsite Ads) do not apply to the item price alone. They apply to the gross order total:

$$\text{Gross Chargeable Revenue} = \text{Item Price} + \text{Buyer-Paid Shipping} + \text{Gift Wrap} - \text{Discounts}$$

> **Important**: If an item is $20.00 and shipping charged to the buyer is $5.00, Etsy calculates percentage fees on **$25.00**, not $20.00.

---

## 2. Core Mandatory Platform Fees

Every Etsy sale incurs three baseline charges:

### A. Listing Fee ($0.20 USD)
* **Amount**: $0.20 USD per listing.
* **Frequency**: Charged when a listing is created, renewed every 4 months, or auto-renewed upon sale for multi-quantity items.
* **Currency Note**: Converted to your local currency at Etsy's exchange rate on the date of listing.

### B. Transaction Fee (6.5%)
* **Rate**: 6.5% of the gross order total.
* **Base**: Includes item price, buyer-paid shipping, personalization, and gift wrapping.

### C. Etsy Payments Processing Fee
If you use Etsy Payments (mandatory in supported countries), Etsy charges a payment processing fee based on your bank account location.

| Seller Bank Country | Percentage Fee | Fixed Per-Order Fee |
| :--- | :--- | :--- |
| **United States** | 3.0% | + $0.25 USD |
| **United Kingdom** | 4.0% | + £0.20 GBP |
| **Canada (Domestic)** | 3.0% | + $0.25 CAD |
| **Canada (International)** | 4.0% | + $0.25 CAD |
| **Eurozone (e.g. France, Germany)** | 4.0% | + €0.30 EUR |
| **Australia** | 3.0% | + A$0.25 AUD (+ 10% GST on fee) |

---

## 3. Conditional & Regional Fees

Depending on seller location and sales volume, your shop may incur additional fee lines:

### A. Etsy Offsite Ads (12% or 15%)
Etsy places ads for your products on Google, Facebook, Instagram, Pinterest, and Bing. You only pay a fee when a click leads to an order within 30 days.

* **Standard Sellers (< $10,000 USD sales in past 365 days)**:
  * **15% fee** on the attributed order total.
  * Optional: You can opt out in shop settings.
* **High-Volume Sellers (≥ $10,000 USD sales in past 365 days)**:
  * **12% fee** on the attributed order total.
  * Mandatory: You cannot opt out for the lifetime of your account.
  * Fee Cap: Maximum $100 USD ad fee per order.

### B. Regulatory Operating Fees
Sellers in select countries pay a Regulatory Operating Fee to cover local Digital Services Taxes (DST) imposed on marketplaces.

* **United Kingdom**: 0.32% of order revenue
* **France**: 0.47% of order revenue
* **Italy**: 0.33% of order revenue
* **Spain**: 0.43% of order revenue
* **Turkey**: 1.1% of order revenue
* **Vietnam**: 0.5% of order revenue

### C. Currency Conversion Fee (2.5%)
If you list items in a currency different from your payout bank account currency (for example, listing in USD from a UK bank account), Etsy charges a **2.5% currency conversion fee** on the total order amount before converting the funds.

---

## 4. Complete Order Case Study

Consider a seller in the United States selling a handmade craft item:

* **Item Price**: $35.00
* **Buyer Shipping Charged**: $5.00
* **Total Order Revenue**: $40.00
* **Product Material Cost**: $8.00
* **Actual Shipping Label Cost**: $4.50
* **Packaging & Labor**: $2.50

### Scenario A: Organic Sale (No Offsite Ads)

1. **Listing Fee**: $0.20
2. **Transaction Fee (6.5% of $40.00)**: $2.60
3. **Payment Processing (3.0% of $40.00 + $0.25)**: $1.45
4. **Total Etsy Fees**: $\$0.20 + \$2.60 + \$1.45 = \$4.25$
5. **Direct Costs**: $\$8.00 + \$4.50 + \$2.50 = \$15.00$
6. **Net Seller Profit**: $\$40.00 - \$15.00 - \$4.25 = \$20.75$
7. **Profit Margin**: $\frac{\$20.75}{\$40.00} \times 100\% = \mathbf{51.88\%}$

### Scenario B: Attributed Sale (15% Offsite Ads)

1. **Core Etsy Fees**: $4.25
2. **Offsite Ads Fee (15% of $40.00)**: $6.00
3. **Total Etsy Fees**: $\$4.25 + \$6.00 = \$10.25$
4. **Net Seller Profit**: $\$40.00 - \$15.00 - \$10.25 = \$14.75$
5. **Profit Margin**: $\frac{\$14.75}{\$40.00} \times 100\% = \mathbf{36.88\%}$

---

## 5. Order Profit Formula & Checklist

To verify your listings, calculate net profit using this sequence:

$$\text{Net Profit} = \text{Order Total} - (\text{Listing} + \text{Transaction} + \text{Processing} + \text{Ad Fees} + \text{Regulatory Fees}) - \text{COGS} - \text{Shipping Cost}$$

### Seller Pre-Publish Checklist
1. **Always list in your bank account's native currency** to avoid the 2.5% conversion penalty.
2. **Model for Offsite Ads worst-case**: Ensure your product remains profitable even if an order incurs a 12% or 15% ad charge.
3. **Track multi-quantity renewals**: Remember that every item sold from a multi-quantity listing immediately triggers a $0.20 auto-renewal fee.
4. **Audit monthly payout CSVs**: Reconcile Etsy's monthly payment account statements against your price estimates to spot regional fee discrepancies.

To test your pricing and margins across organic and ad-attributed sales, run your numbers through the [Etsy Fee Calculator](/tools/ecommerce/etsy-fee-calculator).
26:["$","$L27",null,{"slug":"etsy-fee-complete-guide","initialMarkdown":"$28"}]
