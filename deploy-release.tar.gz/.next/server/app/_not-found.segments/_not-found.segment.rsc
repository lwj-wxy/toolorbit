1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
3:I[837457,["/_next/static/chunks/0ywkc-4sl20yh.js","/_next/static/chunks/187jubqbbak9g.js","/_next/static/chunks/0r5yttdyrak~f.js","/_next/static/chunks/0pct.mc7q8w0q.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"YDcZ9bWEyJw1fM-N9rUXp"}
