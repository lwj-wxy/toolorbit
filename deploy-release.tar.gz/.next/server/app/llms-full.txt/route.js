var R=require("../../chunks/[turbopack]_runtime.js")("server/app/llms-full.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0h-4f.r._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/src_0a8~3_r._.js")
R.c("server/chunks/_next-internal_server_app_llms-full_txt_route_actions_11kft9v.js")
R.m(524636)
module.exports=R.m(524636).exports
