(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["chunks/_next-internal_server_app_og-image_route_actions_0tr8i~v.js",862237,s=>{"use strict";s.s([])}]);

//# sourceMappingURL=_next-internal_server_app_og-image_route_actions_0tr8i~v.js.map