module.exports=[936242,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_navigation-menu_route_actions_0xk91rs.js.map