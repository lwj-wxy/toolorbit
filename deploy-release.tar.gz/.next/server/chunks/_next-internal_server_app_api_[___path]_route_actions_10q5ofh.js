module.exports=[934506,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_%5B___path%5D_route_actions_10q5ofh.js.map