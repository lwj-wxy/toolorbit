module.exports=[2121,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_tools_%5Bsection%5D_page_actions_07o1kfg.js.map