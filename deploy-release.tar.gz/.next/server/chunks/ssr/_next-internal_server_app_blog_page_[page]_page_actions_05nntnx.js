module.exports=[70679,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_blog_page_%5Bpage%5D_page_actions_05nntnx.js.map