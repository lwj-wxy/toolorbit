module.exports=[524259,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_tools_%5Bsection%5D_%5Bslug%5D_page_actions_10h6um6.js.map