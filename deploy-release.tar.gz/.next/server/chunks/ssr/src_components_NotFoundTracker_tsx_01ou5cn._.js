module.exports=[792868,a=>{"use strict";var b=a.i(572131),c=a.i(609093);a.s(["default",0,function(){return(0,b.useEffect)(()=>{let a=window.location.pathname+window.location.search;c.analytics.trackEvent({category:"Routing",action:"page_not_found",label:a,metadata:{requested_path:a}})},[]),null}])}];

//# sourceMappingURL=src_components_NotFoundTracker_tsx_01ou5cn._.js.map