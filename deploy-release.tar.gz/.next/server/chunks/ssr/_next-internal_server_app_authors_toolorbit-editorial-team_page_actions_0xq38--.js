module.exports=[921366,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_authors_toolorbit-editorial-team_page_actions_0xq38--.js.map