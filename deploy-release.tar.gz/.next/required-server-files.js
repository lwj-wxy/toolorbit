self.__SERVER_FILES_MANIFEST={
  "version": 1,
  "config": {
    "env": {},
    "webpack": null,
    "typescript": {
      "ignoreBuildErrors": false
    },
    "typedRoutes": false,
    "distDir": ".next",
    "cleanDistDir": true,
    "assetPrefix": "",
    "cacheMaxMemorySize": 52428800,
    "configOrigin": "next.config.ts",
    "useFileSystemPublicRoutes": true,
    "generateEtags": true,
    "pageExtensions": [
      "tsx",
      "ts",
      "jsx",
      "js"
    ],
    "poweredByHeader": false,
    "compress": true,
    "images": {
      "deviceSizes": [
        640,
        750,
        828,
        1080,
        1200,
        1920,
        2048,
        3840
      ],
      "imageSizes": [
        32,
        48,
        64,
        96,
        128,
        256,
        384
      ],
      "path": "/_next/image",
      "loader": "default",
      "loaderFile": "",
      "domains": [],
      "disableStaticImages": false,
      "minimumCacheTTL": 14400,
      "formats": [
        "image/webp"
      ],
      "maximumRedirects": 3,
      "maximumResponseBody": 50000000,
      "dangerouslyAllowLocalIP": false,
      "dangerouslyAllowSVG": false,
      "contentSecurityPolicy": "script-src 'none'; frame-src 'none'; sandbox;",
      "contentDispositionType": "attachment",
      "localPatterns": [
        {
          "pathname": "**",
          "search": ""
        }
      ],
      "remotePatterns": [],
      "qualities": [
        75
      ],
      "unoptimized": false,
      "customCacheHandler": false
    },
    "devIndicators": {
      "position": "bottom-left"
    },
    "onDemandEntries": {
      "maxInactiveAge": 60000,
      "pagesBufferLength": 5
    },
    "basePath": "",
    "sassOptions": {},
    "trailingSlash": false,
    "i18n": null,
    "productionBrowserSourceMaps": false,
    "excludeDefaultMomentLocales": true,
    "reactProductionProfiling": false,
    "reactStrictMode": null,
    "reactMaxHeadersLength": 6000,
    "httpAgentOptions": {
      "keepAlive": true
    },
    "logging": {
      "serverFunctions": true,
      "browserToTerminal": "warn"
    },
    "compiler": {},
    "expireTime": 31536000,
    "staticPageGenerationTimeout": 60,
    "modularizeImports": {
      "@mui/icons-material": {
        "transform": "@mui/icons-material/{{member}}"
      },
      "lodash": {
        "transform": "lodash/{{member}}"
      }
    },
    "outputFileTracingRoot": "C:\\Users\\StandardSoftware\\Desktop\\my-project\\toolorbit",
    "cacheComponents": false,
    "cacheLife": {
      "default": {
        "stale": 300,
        "revalidate": 900,
        "expire": 4294967294
      },
      "seconds": {
        "stale": 30,
        "revalidate": 1,
        "expire": 60
      },
      "minutes": {
        "stale": 300,
        "revalidate": 60,
        "expire": 3600
      },
      "hours": {
        "stale": 300,
        "revalidate": 3600,
        "expire": 86400
      },
      "days": {
        "stale": 300,
        "revalidate": 86400,
        "expire": 604800
      },
      "weeks": {
        "stale": 300,
        "revalidate": 604800,
        "expire": 2592000
      },
      "max": {
        "stale": 300,
        "revalidate": 2592000,
        "expire": 31536000
      }
    },
    "cacheHandlers": {},
    "experimental": {
      "appNewScrollHandler": false,
      "useSkewCookie": false,
      "cssChunking": true,
      "multiZoneDraftMode": false,
      "appNavFailHandling": false,
      "prerenderEarlyExit": true,
      "serverMinification": true,
      "linkNoTouchStart": false,
      "caseSensitiveRoutes": false,
      "cachedNavigations": false,
      "partialFallbacks": false,
      "dynamicOnHover": false,
      "varyParams": false,
      "prefetchInlining": false,
      "preloadEntriesOnStart": true,
      "clientRouterFilter": true,
      "clientRouterFilterRedirects": false,
      "fetchCacheKeyPrefix": "",
      "proxyPrefetch": "flexible",
      "optimisticClientCache": true,
      "manualClientBasePath": false,
      "cpus": 17,
      "memoryBasedWorkersCount": false,
      "imgOptConcurrency": null,
      "imgOptTimeoutInSeconds": 7,
      "imgOptMaxInputPixels": 268402689,
      "imgOptSequentialRead": null,
      "imgOptSkipMetadata": null,
      "isrFlushToDisk": true,
      "workerThreads": false,
      "optimizeCss": false,
      "nextScriptWorkers": false,
      "scrollRestoration": false,
      "externalDir": false,
      "disableOptimizedLoading": false,
      "gzipSize": true,
      "craCompat": false,
      "esmExternals": true,
      "fullySpecified": false,
      "swcTraceProfiling": false,
      "forceSwcTransforms": false,
      "largePageDataBytes": 128000,
      "typedEnv": false,
      "parallelServerCompiles": false,
      "parallelServerBuildTraces": false,
      "ppr": false,
      "authInterrupts": false,
      "webpackMemoryOptimizations": false,
      "optimizeServerReact": true,
      "strictRouteTypes": false,
      "viewTransition": false,
      "removeUncaughtErrorAndRejectionListeners": false,
      "validateRSCRequestHeaders": false,
      "staleTimes": {
        "dynamic": 0,
        "static": 300
      },
      "reactDebugChannel": true,
      "serverComponentsHmrCache": true,
      "staticGenerationMaxConcurrency": 8,
      "staticGenerationMinPagesPerWorker": 25,
      "transitionIndicator": false,
      "gestureTransition": false,
      "inlineCss": false,
      "useCache": false,
      "globalNotFound": false,
      "browserDebugInfoInTerminal": "warn",
      "lockDistDir": true,
      "proxyClientMaxBodySize": 10485760,
      "hideLogsAfterAbort": false,
      "mcpServer": true,
      "turbopackFileSystemCacheForDev": true,
      "turbopackFileSystemCacheForBuild": false,
      "turbopackInferModuleSideEffects": true,
      "turbopackPluginRuntimeStrategy": "childProcesses",
      "optimizePackageImports": [
        "lucide-react",
        "motion",
        "react-i18next",
        "react-markdown",
        "react-syntax-highlighter",
        "date-fns",
        "lodash-es",
        "ramda",
        "antd",
        "react-bootstrap",
        "ahooks",
        "@ant-design/icons",
        "@headlessui/react",
        "@headlessui-float/react",
        "@heroicons/react/20/solid",
        "@heroicons/react/24/solid",
        "@heroicons/react/24/outline",
        "@visx/visx",
        "@tremor/react",
        "rxjs",
        "@mui/material",
        "@mui/icons-material",
        "recharts",
        "react-use",
        "effect",
        "@effect/schema",
        "@effect/platform",
        "@effect/platform-node",
        "@effect/platform-browser",
        "@effect/platform-bun",
        "@effect/sql",
        "@effect/sql-mssql",
        "@effect/sql-mysql2",
        "@effect/sql-pg",
        "@effect/sql-sqlite-node",
        "@effect/sql-sqlite-bun",
        "@effect/sql-sqlite-wasm",
        "@effect/sql-sqlite-react-native",
        "@effect/rpc",
        "@effect/rpc-http",
        "@effect/typeclass",
        "@effect/experimental",
        "@effect/opentelemetry",
        "@material-ui/core",
        "@material-ui/icons",
        "@tabler/icons-react",
        "mui-core",
        "react-icons/ai",
        "react-icons/bi",
        "react-icons/bs",
        "react-icons/cg",
        "react-icons/ci",
        "react-icons/di",
        "react-icons/fa",
        "react-icons/fa6",
        "react-icons/fc",
        "react-icons/fi",
        "react-icons/gi",
        "react-icons/go",
        "react-icons/gr",
        "react-icons/hi",
        "react-icons/hi2",
        "react-icons/im",
        "react-icons/io",
        "react-icons/io5",
        "react-icons/lia",
        "react-icons/lib",
        "react-icons/lu",
        "react-icons/md",
        "react-icons/pi",
        "react-icons/ri",
        "react-icons/rx",
        "react-icons/si",
        "react-icons/sl",
        "react-icons/tb",
        "react-icons/tfi",
        "react-icons/ti",
        "react-icons/vsc",
        "react-icons/wi"
      ],
      "trustHostHeader": false,
      "isExperimentalCompile": false
    },
    "htmlLimitedBots": "[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight",
    "bundlePagesRouterDependencies": false,
    "configFileName": "next.config.ts",
    "turbopack": {
      "root": "C:\\Users\\StandardSoftware\\Desktop\\my-project\\toolorbit"
    },
    "distDirRoot": ".next",
    "_originalRedirects": [
      {
        "source": "/blog/coffee-caffeine-guide",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/coffee-caffeine-guide",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/sugar-content-rankings",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/sugar-content-rankings",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/remote-work-ergonomics",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/remote-work-ergonomics",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/ai-ecommerce-marketing-tips",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/ai-ecommerce-marketing-tips",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/xiaohongshu-copywriting-ai",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/xiaohongshu-copywriting-ai",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/benefits-of-chinese-crypto-sm",
        "destination": "/blog",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/benefits-of-chinese-crypto-sm",
        "destination": "/zh-CN/blog",
        "permanent": true
      },
      {
        "source": "/blog/what-fees-does-etsy-charge-sellers",
        "destination": "/blog/etsy-fee-complete-guide",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/what-fees-does-etsy-charge-sellers",
        "destination": "/zh-CN/blog/etsy-fee-complete-guide",
        "permanent": true
      },
      {
        "source": "/blog/etsy-shipping-cost-profit-impact",
        "destination": "/blog/etsy-shipping-free-shipping-strategy",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/etsy-shipping-cost-profit-impact",
        "destination": "/zh-CN/blog/etsy-shipping-free-shipping-strategy",
        "permanent": true
      },
      {
        "source": "/blog/etsy-offsite-ads-fee-profit-impact",
        "destination": "/blog/etsy-offsite-ads-explained",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/etsy-offsite-ads-fee-profit-impact",
        "destination": "/zh-CN/blog/etsy-offsite-ads-explained",
        "permanent": true
      },
      {
        "source": "/blog/etsy-payment-processing-fees-by-country",
        "destination": "/blog/etsy-international-selling-fees",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/etsy-payment-processing-fees-by-country",
        "destination": "/zh-CN/blog/etsy-international-selling-fees",
        "permanent": true
      },
      {
        "source": "/blog/maximizing-profit-on-etsy",
        "destination": "/blog/etsy-pricing-strategy-guide",
        "permanent": true
      },
      {
        "source": "/zh-CN/blog/maximizing-profit-on-etsy",
        "destination": "/zh-CN/blog/etsy-pricing-strategy-guide",
        "permanent": true
      },
      {
        "source": "/:locale(ja-JP|zh-Hant)/:path*",
        "destination": "/:path*",
        "permanent": true
      },
      {
        "source": "/tools/fee-calculator",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/fee-calculator",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/shared/placeholder",
        "destination": "/tools",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/shared/placeholder",
        "destination": "/zh-CN/tools",
        "permanent": true
      },
      {
        "source": "/tools/etsy/fee-calculator",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/fee-calculator/:detail*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/fee-calculator",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/profit",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/profit/:detail*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/profit",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/monthly-profit",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/monthly-profit/:detail*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/monthly-profit",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/break-even",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/break-even/:detail*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/break-even",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/conversion-rate",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/conversion-rate/:detail*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/conversion-rate",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/discount",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/discount/:detail*",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/discount",
        "destination": "/zh-CN/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/free-shipping",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/free-shipping/:detail*",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/free-shipping",
        "destination": "/zh-CN/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/bundle-profit",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/bundle-profit/:detail*",
        "destination": "/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/bundle-profit",
        "destination": "/zh-CN/tools/ecommerce/etsy-pricing-calculator",
        "permanent": true
      },
      {
        "source": "/tools/etsy/:path*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/etsy/:path*",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/solutions/:path*",
        "destination": "/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/zh-CN/solutions/:path*",
        "destination": "/zh-CN/tools/ecommerce/etsy-fee-calculator",
        "permanent": true
      },
      {
        "source": "/tools/dev/chinese-crypto",
        "destination": "/tools/dev/crypto-symmetric",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/dev/chinese-crypto",
        "destination": "/zh-CN/tools/dev/crypto-symmetric",
        "permanent": true
      },
      {
        "source": "/tools/fun/game-2048",
        "destination": "/tools",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/fun/game-2048",
        "destination": "/zh-CN/tools",
        "permanent": true
      },
      {
        "source": "/tools/fun/minesweeper",
        "destination": "/tools",
        "permanent": true
      },
      {
        "source": "/zh-CN/tools/fun/minesweeper",
        "destination": "/zh-CN/tools",
        "permanent": true
      },
      {
        "source": "/category/fun-tools",
        "destination": "/tools",
        "permanent": true
      },
      {
        "source": "/zh-CN/category/fun-tools",
        "destination": "/zh-CN/tools",
        "permanent": true
      }
    ]
  },
  "appDir": "C:\\Users\\StandardSoftware\\Desktop\\my-project\\toolorbit",
  "relativeAppDir": "",
  "files": [
    ".next\\routes-manifest.json",
    ".next\\server\\pages-manifest.json",
    ".next\\build-manifest.json",
    ".next\\prerender-manifest.json",
    ".next\\server\\functions-config-manifest.json",
    ".next\\server\\middleware-manifest.json",
    ".next\\server\\middleware-build-manifest.js",
    ".next\\server\\app-paths-manifest.json",
    ".next\\app-path-routes-manifest.json",
    ".next\\server\\server-reference-manifest.js",
    ".next\\server\\server-reference-manifest.json",
    ".next\\server\\prefetch-hints.json",
    ".next\\BUILD_ID",
    ".next\\server\\next-font-manifest.js",
    ".next\\server\\next-font-manifest.json",
    ".next\\required-server-files.json"
  ],
  "ignore": []
}